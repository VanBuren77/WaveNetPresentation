1. https://redcatlabs.com/2018-01-23_TFandDL_WaveNets/#/
2. https://youtu.be/YyUXG-BfDbE
3. https://youtu.be/BIMk_eo5FKc
4. 