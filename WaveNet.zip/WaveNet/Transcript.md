  
0:05

probably if you've been here before you know something about me I moved from New

0:10

York City I'm originally English I removed from New York City in September 2013 2014 was kind of sabbatical year

0:18

when I just focused on machine learning deep learning natural act processing did

0:24

some robots and drones but since 2015 I've been in kind of serious mode and

0:30

I'm doing natural language processing deep learning I've managed to write a few papers along the way recently we

0:36

were at nips or IED Sam and I went to nips which is fantastic and we've also been teaching a developer course so

0:42

things are beginning to turn turn into something now so the outline of this I'm

0:49

going to talk a little bit about wavenet version one and then what it's made out of and then some enhancements so there's

0:55

firstly there was fast wavenet which is a like a necessary optimization but then

1:02

we into parallel wavenet which is a whole new ballgame and that is what is shown on people's googles home in

1:10

America and in Japan but why is it excitement and what how did that work so

1:18

wavenet version 1d you came from google deepmind so Google acquired deep mind a

1:23

while ago this is one kind of concrete product which they came out of it and in

1:31

this the splash blog post they had they announced the the paper and also it has

1:37

some nice clickable audio examples so this presentation I've put links up on you know in the Meetup you can click on

1:45

these get to the web page the key thing here though the reason it is exciting is

1:51

that if this is human speech with this kind of mean opinion score and these are

1:57

the these two are the previous ways of doing it so suddenly wavenet is a whole lot closer to being

2:05

human-like so this was no dramatically better and so this was the blog post which came

2:12

out and they explained how basically you

2:18

know this low-res you know they're actually predicting audio samples so this is what they're doing this that

2:24

clever thing and they have little diagrams which is very nice is that here's the thing and basically let me

2:31

just play some audio hopefully this is going to come out of my speakers the

2:36

1980 American romance an adventure film directed by Randal Kleiser can anyone

2:41

hear that aspects of the sublime in English poetry and painting 1772 1850 is

2:49

he coming out at all I barely have to

3:02

aspects of the sublime in English poetry and painting 1772 18 try again aspects

3:12

of the sublime in English poetry and painting 1772 1850 okay so this this the

3:19

way in which this first one is done is they have a like a speech synthesizer which is something where they're moving

3:25

the parameters around on this very quickly so it's trying to make a synthesizer output speech and so what

3:32

happens here is it tends to feel a bit singsong II it's a bit weird a bit kind

3:38

of lumpy in a way that is which is

3:46

commonly used and say Apple will use is concatenative so what they do for this

3:51

is they pick that they know what's in what phonemes you're going to be producing and they're going to pick out

3:57

of a large corpus what is the closest match to that phoneme and just output the wave signal and then blend them all

4:03

together so basically this is taking from a corpus of speech like the closest

4:09

thing what you're trying to say and just hitting the speak with it so this used

4:19

to be kind of the winner in the quality war just because you know each individual segment of it is pretty high

4:24

quality but the problem is if you if you listen to it carefully now I'll tell you

4:30

what what's now now you tell you what to listen for you'll hear that it's going from little boost it up and down like

4:37

the song is all wrong because it's taken from the song from a completely different corpus and so it jumps around

4:42

all over the place aspects of the sublime in English poetry and painting so it's got it's got the

4:52

individual sounds right but it's got the song of English wrong whereas this thing will get the song of English correct but

4:58

the sounds are wee bit of the sublime in English poetry at painting 17 70 to 80

5:05

okay so long comes wavenet aspects of the sublime in English poetry and

5:10

painting 1772 1850 can people hear that that's mark be better okay well these

5:16

it's not me this is the google play so this is suddenly suddenly deepmind comes along and they've done something really

5:23

pretty good so if we look at Mandarin Chinese which is I know nothing about but but you might be able to hear this

5:34

sounds more like it like a Casio version of someone right was so this is very

5:43

kind of deliberate wavenet so I don't

5:53

I'm not one to say but maybe that's quite good I don't know the other thing which they can do is they can play a

5:59

game with just trying to say let the network loose and just try and say stuff

6:07

without being driven by text doesn't

6:15

Atari i'ma tell you to put this in art are they back here with her so this is kind of a model of human speech which is

6:23

you know that clearly but Victoria taro Seki a district in

6:31

that self-five it's kind of disturbing so basic basically wavenet has

6:38

understood both how to form the individual sounds but also join them together in in a language like way and

6:47

they can also play games with really sir

6:53

the avocado has a pear-shaped fruit with the avocado is a pear-shaped fruit with

6:59

them the avocado is a pear-shaped with letters so they can do multiple speakers just by changing some parameters for

7:05

their network they can also played some games with music which we have no time for so let's just so this is why this

7:12

was kind of exciting is that this is markedly different from what would come before and so I'll just explain what the

7:19

key elements of this were one by one so one of the important things is that they

7:26

are producing audio samples just as the output of a neural network which is kind of remarkable in the past people have

7:33

been emitting words or maybe some like changing pictures of it but here they're

7:38

predicting individual samples at 16 kilohertz which is it's kind of crazy

7:44

and they're also doing it you know in 8-bit resolution so then I'll give you

7:49

more idea about how that's going but one of the surprising things is a normal recurrent neural network which is how

7:56

you would normally think of producing a time series or or analyzing a time series you're kind of talking about 50

8:02

steps is kind of where it maxes out but these word features are thousands of

8:07

steps in in space in so in time for these things so how they analyzing this

8:13

and so this is kind of one of the remarkable things now one one of the

8:18

things they did where you can't use recurrent neural networks or standard recurrent neural networks so let's use

8:24

convolutional neural networks and these are familiar from the vision like computer vision people but one of the

8:30

problems with that is if I have a network which is four layers deep basically I only go four layers back in

8:36

title 4 time steps back in time in order to go a thousand times it's back in time I had to have thousand

8:42

layers so this this is a problem so it kind of has a linear footprint so what

8:50

the one innovation here is they have these dilated cnn's and you'll see that

8:56

at the bottom we have just saw a one stepper but the next one up has a skip of two and the next one up above that

9:03

will have a skip of four and then a skip of eight by having this if you if you look basically you can join them on now

9:10

you've got kind of like an exponential length of time you could be referencing I mean clearly you're not referencing

9:18

this piece you're only referencing bits of the past but at least you have some idea of going much further back so then

9:24

if you have a ten layer deep thing you can go back a thousand steps okay another thing which they do is it whoa

9:31

so with with CNN's you've got the pros and cons I mean the advantage of this is you can get this very long look back and

9:37

you can train it faster basically all you need to do is you have your here's my time steps for my long piece of

9:46

speech as input what I wanted to predict is the next sample at every stage but I

9:51

can now I know what that is just by using the same sequence shift it back by one so that will allow me to align input

9:58

to output for every single time step in just one training example across thousands and thousands of because

10:05

there's some kind of a time invariance going on in that it doesn't matter what second you speak a particular word it's

10:12

all going to be the same but within that second that you need to capture that

10:17

whole variance on the other and the disadvantage is how do you know what the next sample is I've now got to carry

10:24

suppose I predicted a sample at time 0 to time 1 I now need to carry that time

10:30

1 sample back to the bottom of my CNN and evaluate this massive thing thousands upon thousands of times in

10:37

order to get a sequence of speech whereas with an RNN I could just go one

10:43

sample to the next sample to the next sample to the next sample at the next song another thing which they do is at each

10:51

of these dots which has got this kind of gathering mechanism is not just a simple

10:57

multiply an ad they actually have this they divide it into two pieces and they

11:03

do a tan on one side and a sigmoid on the other multiply them together then do a one by one convolution and then add

11:09

them to what you first thought of and this is one of those dots so this this

11:15

kind of extra complexity this kind of gated unit also add something clearly

11:21

add something otherwise they wouldn't have put it in because I don't think they want to just burn money though the

11:27

outcome of this is they do burn money so the other thing which they do is they have these side chains so across all of

11:34

the eve each of these individual circles also have feeds into this thing which is

11:39

a chain of essentially convolution of one dimensional con 1x1 convolutional

11:44

layers in order to get to a softmax which is the output so the output is fed

11:51

kind of sideways you've got this vertical breakdown of of time and sideways is kind of the sum of all

11:58

possible times for each sample but the other thing is that they're not

12:04

producing a single number at each each time step they produce a whole distribution of what it thinks the next

12:11

sample should be so instead of having a neural network produces is trying to

12:17

track the the exact number which is like a you could do a regression for it you

12:22

know here's here is the perfect value to come out with it's actually producing like a scatter diagram of guess where

12:28

the number should be and so clearly they find that this is the better way to do it but it does seem crazy that you're

12:36

doing 256 times as much work as you would do is you're just producing a single number but the results kind of

12:45

prove that it was worth doing so as I mentioned before there's a computational

12:50

burden the trainees kind of quick but every time step you know what your next

12:56

training sample should be so you can do in them also Dainius lee in parallel but when you

13:01

come to actually running this for output is extremely slow and so one second of

13:07

audio output using deep minds resources was I think one or two minutes of GPU

13:13

time so this is why all of the samples they have a really small because it took them hours and hours to produce these

13:19

things um this is clearly impractical in particular if I ask my Google home what

13:26

is the weather like it will then have to think for several hours before outputting the the answer

13:32

anyway that they carried forwards that they they also had they kept themselves busy with alphago as well so you know

13:37

they had stuff to do okay so now we're with wavenet one and then it's talked a

13:43

bit about the implementations there's one intensive flow called I someone I

13:48

bad most people just think this is kind of the reference implementation surprisingly there aren't hundreds of

13:54

implementations of this but I guess it's Soto so type consuming to train people

14:00

are talking about getting sample results after a week on their Titan X right so

14:06

this thing takes a long time to do something which is half okay deep mind

14:14

clearly had a lot of processing power to play with this there's another thing called there's a project cut by Google

14:19

called magenta which is really cool and I can give you quick aside on this and they actually have code on github

14:25

because they've implemented wavelet for themselves so this is kind of from what I see the most official Google

14:32

implementation let me just show you the so this is this is the magenta project

14:39

basically they've got a whole bunch of interesting like games to play they have

14:46

this kind of people were doing quick-draw if you haven't seen this it's super fun to play this is kind of you

14:51

draw a little bit and then it comes up with more diagrams or they play this music

15:01

[Music] okay so this is this is random Chopin

15:12

which they've trained and like a LST em just like producing the works of

15:17

Shakespeare by reading the works of Shakespeare they're doing the same for kind of expressive piano playing it

15:22

seems that this is a this is a place in Google where people have fun so they

15:28

also have cave come up with this n synth which does not or do synthesis which

15:34

includes a wavenet decoder on the other hand when you play these samples

15:40

prepared to be disappointed compared to the deep mind voices anyway you may find

15:49

it to be fun and then here's a beard okay there we go okay now now it's time

15:57

to show the the actual singapura implementation of this thing and I have

16:03

to preface this by saying it doesn't do a very great training of anything I just wanted to get the code out there in a

16:10

working state so it'll do something now the the hotness which I'm doing so this

16:15

is kind of so there's some at least some tensorflow takeaway here is it uses the new dataset API which I'm sure the

16:23

Googlers will have witted on about in December and it produces TF records and

16:29

it streams streams and from disk so this is something where the tensorflow examples actually just read the stuff

16:35

from memory it's kind of frustrating and I see some nodding hit so the tense of low examples in there just have em 'no

16:42

stand read it from memory and you're like well the whole point of this is to read it from disk because i want to do

16:47

it asynchronously another thing which is is this is a Karass model which I've exported to being an estimator so this

16:54

allows you to do the estimator thing which will then allow you to run this on CPUs or on your mobile or all sorts of

17:00

other interesting things and it's in one notebook which works into end

17:07

and let's just edit that so I don't think I want to execute this but

17:13

basically the the flow of this is what I'm the tasks I'm trying to do is to

17:19

take speech reduce it to its Mel's spectrograms which is a spectrogram like

17:25

compressed and then expand it out into good speech again which is kind of what

17:30

wavelet is doing but I just wanted to have my own little go and basically I've

17:36

got some librivox books which have quite well spoken I just want to read those in

17:42

as mp3 so here's some kind of FFT things

17:47

I read them in this is I read in these samples or I do an FFT I then start to

17:55

write these tensor flow records out and so this is something which you probably need to download a look at the code if

18:01

you cared because it it took a while to do this so one of the one of the other

18:09

lessons which I do is I actually pre process everything before I write it to disk now the tensor flow people seem to

18:15

want you to process it as it flies off the disk on the other hand just doing

18:21

simple processing proved to be such a documentation nightmare as far easier

18:27

just to do it in numpy and save it on disk so perhaps this is easy to do intensive flow there was there's an

18:33

example of how I did do it intents to flow and then just gave up because manipulating these complex numbers no

18:39

fun at all where's in lumpy I can just do it so basically I take these spectra

18:46

and these Mel spectra and then look us make some angles make some shapes um

18:51

store it into disk with phases I comes in is I can take this data set and like

19:40

posit and I can shuffle it or batch it or make

19:47

into an iterator so this this last bit is is the magic working for me but it

19:53

took an awful long time to setup the magic before that would set up the trick before the magic would work and it also

20:00

I have to say it also feels very backwards in the or writing all this code and you won't be able to ever run

20:07

it for two days because you have to run them write the model and everything else before you'll even try and suck the data

20:12

in so anyway that's the experience so

20:18

now I'm gonna announce it up so I know I have some data which I could read in if I had something which would try and pull

20:24

the data so I'm now going to write a care ass model so I've got two func two

20:30

functions here one of which is a wavenet layer which basically takes it does two of these one deconvolution so this is

20:37

the there's a tan bit and a sigmoid bit and it has this dilation rate which is

20:44

the skipping and now it multiplies them together it pads it out a bit and then

20:51

it does this skip out and here's the residual thing so so basically this is a

20:56

single node on that tensor flow graph including the relation and then in order

21:03

to get the actual for the model which is mine Mel spectrograms to the full spectrum I now just say okay I'll take

21:09

my inputs and I'll now do I've got five layers here of wavenet and I then kind

21:18

of make stuff happen so so basically this is the wavelet thing being used now

21:24

one of the issues that I found is that the Kerr ass internal to tensorflow is now different from the Karis external

21:31

to tensorflow in that the Karis external sensor foe works and the one inside tensorflow

21:37

doesn't according to the docs so there are parameters in the ones

21:42

which the Doc's don't match what happens in the code and when Francois Chalet is

21:48

asked about this he says submit a pull request to tensorflow and closes the issue

21:54

this is not not helpful now the reason I want to use the internal tensorflow

21:59

version is because that is the only one which has the tents of the Charis to estimate a function the Charis to

22:06

estimate a function doesn't work on the external staff for some mysterious incompatibility reason anyway so what

22:14

happens out of this so Kerris is nice you can build a model and out comes a

22:19

nice nice model which carrots can explain carrots there's all this nice stuff which is why it's quite nice to use I can build a custom loss I can do

22:28

dirt the dirt the dirt the dirt there and then I can set up a training

22:34

specification and an evaluation specification and now I can run the mat so that's setting up the magic trick and

22:40

this is the magic I now just run train and evaluate and they will do all the right stuff so if your run training and

22:48

evaluates because I've got essentially this input function reads the stuff from

22:54

the data sets this thing all feeds into itself and trains the model with the right training staff and if I look on

23:00

tensor board it's reduced me a beautiful diagram if I look okay we've got some

23:07

basically some graphs of the training performance all of this stuff is all beautifully done once it connects up but

23:15

I can tell you is not easy anyway so there we have so this thing will produce

23:21

beautiful graphs of thing I can stop it I can make predictions and so let's so

23:27

this is not really a very good demo because it doesn't sound very good but this is the original that is what must

23:42

have had in mind so clearly this is a good English speaker speaking some book

23:48

this is about bachelors in English in LibriVox and the text is free because

23:53

it's good and book press and all the speech files are free like free of any obligation or maybe there's a

24:00

attribution here so but it's very nicely done

24:05

so one thing which I do is is if you then take I convert that to Mel spectra and I then say well let's just convert

24:12

this back into the real spectrum yes and then render that to text and it sounds

24:21

like let me just sorry let me just make sure that works

24:37

so this kind of shows that the phase information flex spectra consists of

24:42

real magnitudes and a phase number and so this is why it sounds like it's

24:48

horribly phasing it sounds like it's gone through a phaser because it's precise I've set this all the phases to

24:53

exactly zero here so this is what it this is how I just use the real part

24:59

you're sorry the absolute part now I can prove to myself that the actual mel

25:05

conversion bit worked okay by using my

25:10

predictions plus the original phases so

25:20

this kind of proves that if I could get the phase stuff right then I'd be in business okay so if I now take out these

25:27

things so this is why it's kind of like a non perfect demonstration so we get we

25:34

finally we've done a bit of prediction we get to about 50/50 I would say five

25:44

out of ten compared on the scale so but this is but the it would have been great

25:50

if it reviews perfect speech on the other hand if it had produced perfect speech that will probably be a product and I will probably not be open sourcing

25:58

this trade away right so in a way it's good that it that the version here

26:03

doesn't work so well because it's a perfect example of the chaos and the estimators and everything but it doesn't

26:08

do exactly what we needed to do sorry sorry about that so that was the demo

26:18

so one of the problems with this one minute equals one second or more is it's

26:24

not very fast so people try to speed this up one obvious what one semi obvious way to do this is to essentially

26:32

try and make the lake a lot of this layer computation as you go along in sound of self-referential and so there's

26:39

a thing called fast net wave net which involves queues and so as long as you remember just the right number of things

26:45

which you pre calculated you can calculate this thing a lot faster and this is several hundred times faster

26:51

than it used to be but it's still not fast okay there's a reference to the

26:57

code that was too fast

27:03

so what the next big splash came in October 2017 so basically a year later

27:09

well it's a semi big splash in that there's a blog post which announced that Google assistant now uses wavenet

27:17

because they've done something really smart but they didn't really explain

27:22

what they did so so I've just just so you know I've got a Google home here

27:28

which is an English version which doesn't use wavenet so hey Google can

27:36

you tell me a limerick here's a limerick for you there was a young lady of Sweden

27:42

by Edward Lear there was a young lady of Sweden who went by the slow train to

27:47

Eden when they cried we didn't station she made no observation but thought she should go back to Sweden okay so you can

27:55

hear that it's going up and down so this is this is not wavenet because this is whereas the US ones sound much better so

28:03

you can hear you can kind of that now when you hear computer-generated voices you'll be able to hear what the problems

28:10

are right so I'm sorry to have ruined it for you but the wavenet stuff works really well and clearly other people are

28:17

coming up with good stuff but yeah Google homes not quite there for the English version but what happened

28:25

afterwards fortunately is deepmind then came up with a November post which actually explained what they were doing

28:30

and had a paper presumably because of some conference release days or something and the trick there is

28:39

basically what you want to do is you want to feed in just noise or some kind

28:45

of audio and make it into the nice speech in one go if you could do all

28:50

this in parallel rather than one sample at a time you'd be done because the GPU will just do layer layer layer layer

28:57

layer and I have 10 seconds of speech like I was doing with my with my example

29:03

I just doing 10 second batches basically so the question is how do we make this

29:09

input straighten out into this beautiful output so what they do is they have they

29:15

divide make two synthesizers one of which is this teacher what network which they've

29:20

already trained to do what the original one did what that does is it takes good

29:26

samples and converts them into the next sample so it does the right thing but

29:32

also it produces the distribution of every sample along the way as one of its kind of artifacts what you do with a

29:39

student one is you put in just noise and that will then produce at the end a

29:44

distribution as well as a sample so you can then put the samples into wavenet

29:50

and then it will come out with a distribution so that basically you can

29:56

then say well I'd like the two distributions I can't make the the actual samples to be identical that's

30:02

too much of a goal but I can make the distributions of the samples the same and then basically by converging these

30:09

two distributions to each other you force the teacher can force the student to learn what the distribution should be

30:16

which is to be a good wave net so that they've got this little animation

30:21

basically they they've speeded it up so instead of 0.2 seconds they can produce a lot more so this is so suddenly it's

30:30

now a commercially practical application and that they're doing it by having this

30:35

teacher and student thing now the problem with the teacher and student is if this teacher can be only semi-good

30:41

after a week on your GPU it will only train a really pathetic student right

30:47

you need to train the teacher all the way before it can train the student so this is where there are definite as I

30:54

know there are no implementations of this in the wild just because no one else can run it so this is why I want to

31:00

play around with the spectra things okay so to wrap up we've not started out very good but

31:07

super expensive but because it was so good it proved that it was worth optimizing and there are a ton of smart

31:14

people at these companies in particular deep mind Google which have actually done it and now it's a value a viable

31:20

product where as a year ago it was kind of odd October 2016 it was

31:27

kind of a nice well nice state-of-the-art result but wasn't

31:32

practical anyway but there's lots of one of these things which cool it seems as

31:38

doing with their excessive amounts of hardware is proving that things are possible but that allows other people to

31:44

then come along and say well actually now I know it's possible I can actually train a network to do it because I know

31:49

it can be done whereas before academics were training possibly pushing the envelope upwards but only meant not

31:57

reaching for the sky they were reaching just above where they previously were was coming out with this super good

32:02

result means that people say well you know I don't want to do the little thing I should do the big thing and they

32:08

actually having bigger ideas there's a huge amount of innovation which is possible in this stuff so ok I've got

32:17

some ads we could do this later we could do this now now ok so let's do some quick ads so clearly you know about the

32:25

deep learning meetup group because you're here the next one is the 22nd of

32:31

February that's what we typically aim for is talk for people starting out

32:36

something from the bleeding edge and lightning talks now it may may not be that this one has much for beginners so

32:42

we will see but we're trying at least ok

32:48

here's a bonus piece of news that you can now get from Google via Kaggle which is called collab now or something free

32:56

free 12 hours at the time with a GPU so basically you have like an ipython

33:02

notebook and you can use a GPU for up to 12 hours and it might throw you off occasionally but my guess is they're

33:09

just soaking up all their free GPU time you're doing this on kind of older GPUs

33:15

there's also nice there's a blog post there but free GPU sounds great nuts

33:21

it's great so can I have this cake show of hands can can everyone raise their

33:28

hand everyone this is a this is just a rejection test ok right can everyone

33:34

lower the hand now can everyone who didn't raise their hand before raise it now I tried right okay

33:42

okay who wants it's kind of more in-depth stuff like more eager mode more

33:49

okay okay these are these these are actually the eager people okay okay okay

33:55

who'd like to hear about the text-to-speech race so this thing this deep this wave neck thing is part of

34:03

that but there's also tacit Ron and deep voice and loop there's all sorts of

34:08

things people playing a race for this text-to-speech anyone interested in that some okay um what about text speech to

34:16

text so this is I was seeing a lot of the same okay some more okay okay who

34:23

wants to hear more about Google Cloud ml how interesting okay who wants to under

34:32

wants to hear about the latent space tricks which are being played okay who

34:40

wants to understand who wants to hear about things which are being done with knowledge bases okay or maybe knowledge

34:49

bases and assistance and that kind of thing okay thank you very much um

34:56

another thing which we're doing so there wasn't that much so there may not be that much beginner content today we're

35:01

also doing a kind of deep learning back to basics which will be held at SG innovate which is in carpenter street

35:07

near Clarkie there's one on 6th of March if you came basically a year ago it's

35:16

going to be similar content to the beginner stuff we were doing then so we're kind of catching up with people who didn't attend the Meetup

35:22

but also we're you know we're going to be hopefully not typical beginner thing

35:27

but and also welcome questions but you know we're also conscious that there are

35:33

quite a few kind of beginner ish things and we don't want to duplicate stuff so

35:38

but we're going to play by ear and find out so here is the eight-week deep

35:45

learning developer course which we've talked about a lot last year and well this happened from the 24 the

35:51

September to the 25th of November and it consisted of twice weekly three hour sessions which is a lot and homework

35:58

okay which hads instruction that everyone had individual projects people

36:03

got funded people with which needed it from Singapore and PRS got funded 70% of

36:11

the cost by wsg um who here attended to the course perhaps um and and and that

36:19

guy did to that guy okay okay it was a

36:29

as held a test you innovate this is over but just to say that when we said it would happen it did happen is over okay

36:36

there should be another something week deep learning developer course starting

36:42

sometime soon we do kind of depends on wsg getting their act together we're not

36:50

exactly sure how super time intensive this should be because it was a real struggle but maybe that we do a mix of

36:57

in-person and online or something or leave bigger gaps or something anyway

37:03

and we are also probably be doing a deep learning beginner course but this will

37:09

be slightly more than like an AI Saturday or a one-day event or an Nvidia

37:14

thing the idea is we'd have a full day of stuff to play with real models we've

37:20

done this before but also there'll be kind of a list of projects to actually go away and do with the idea that we'll

37:28

have kind of like a a point a midway point where just to have people got

37:33

problems what's going on and then kind of a wrap-up session so the idea is we

37:39

have some kind of one-on-one thing but also regroup so this would be kind of a what we found from the deep learning

37:46

developer course is actually doing a project is hugely more than just sitting there or or reading a Udacity thing

37:52

having your own project or something you can actually do forces the learning a lot more so there's a link at the bottom

38:00

will post the link in the so that's me okay so okay I'll take

38:08

questions now and we switch over