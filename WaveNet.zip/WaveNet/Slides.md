![[Pasted image 20220429145343.png]]



![[Pasted image 20220429145357.png]]


![[Pasted image 20220429145410.png]]




![[Pasted image 20220429145416.png]]


![[Pasted image 20220429145422.png]]


![[Pasted image 20220429145427.png]]



![[Pasted image 20220429145432.png]]



![[Pasted image 20220429145438.png]]



![[Pasted image 20220429145444.png]]


![[Pasted image 20220429145449.png]]



![[Pasted image 20220429145455.png]]


![[Pasted image 20220429145512.png]]


![[WaveNet-Fig2-Anim-160908-r01_570x262.gif]]


![[Pasted image 20220429145624.png]]


![[Pasted image 20220429145630.png]]


![[Pasted image 20220429145637.png]]
![[WaveNet-Fast_Queues_700x346.png]]


![[Pasted image 20220429145643.png]]

![[Pasted image 20220429145717.png]]


![[Pasted image 20220429145723.png]]
![[Pasted image 20220429145730.png]]


![[WaveNet-Parallel-Speedup_900x506.gif]]


![[Pasted image 20220429145747.png]]

![[Pasted image 20220429145805.png]]
