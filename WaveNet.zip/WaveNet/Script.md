# Draft
_________
### Outstanding Questions:

- Can we clarify this and that it leads to parallel wavenet? : 
	- " At training time, the conditional predictions for all timesteps can be made in parallel because all timesteps of ground truth x are known."
- Why does wavenet beat out GMMs?
- How do our 1x1 Convolutions help exactly?
- What is pooling?
- What are strided convolutions?
- Why aren't pooling or strided convolutions helpful in generating audio samples?

## What is Wavenet?

Deepmind designed Wavenet, which is a convolutional neural network architecture, for the job of creating realistic audio samples. It was initially intended for text-to-speech creation to produce human-sounding voices, but its potential for other sorts of audio generation is also considered and used in music sample generations.

It creates autoregressive predictions, meaning, it takes the previous output and puts it in as the next input value and builds up the audio, one sample at a time. Because it is a deep and convolutional network, training it is challenging and time consuming, so in production based systems, there is an added requirement for parallelization.

## How does it Work?

A Wavenet model can be thought of as a stack of interconnected layers, each node within a layer is a combination of exactly two nodes from the previous layer. With each layer you go up, the dilation increases and so the nodes which combine together are spaced further and further apart. This is the incredibly clever trick at the heart of WaveNet as it allows for a large receptive field (amount of input samples) very cheaply (in relative terms).

This then follows all the way up the network until the final layer which outputs a prediction value. Below is a diagram which represents the concept. If you look closely you’ll see the grey lines in the background which show the true underlying structure of the network. 
For each input chunk the model outputs the same number of values on the output and hence can be trained as if an autoencoder with the target labels being in the input data.


![Example of the Wavenet Layer System](https://haydensansum.github.io/CS205-Waveforms/imgs/wavenet_conv.png)

Causal Dilated Neural Network
____

![[Pasted image 20220504224449.png]]

Dilation

## Building Blocks

To really understand what is going on we need to breakdown a few of the key terminologies used when looking at wavenets and consider the core components used within.


#### Dilated Convolutions

Because this is new information to me and maybe it's new for some people here, although it may be a familiar operation, I just briefly want to touch on what dilated convolutions are. 

Dilations are very computationally efficient convolutions since they use the same size kernel throughout. Dilation convolutions I did for the sake of simplicity. I made a 1D convolutional network, because if I did an example with 2D it would more time to go through. We have here, an input signal with values 1,2,3....7, they are just random values. And we also have a kernel. A dilated kernel, which means we have 2 and a null or 0 and a 1. The kernel gives the output on the right. 

Dilation 1 is a standard kernel and Dilation 2 is the same kernel but with a dilation of 2 and the inserted 0.

https://youtu.be/0Lg_V0Um-1Q


![[Pasted image 20220504231447.png]]


#### A Trous Causal Convolutional Filter

As mentioned briefly above, each node is a combination of two nodes from the previous later - hence a convolutional layer with kernel size = 2. The convolution means that the same filter is applied and trained across all of the data points (almost as if sliding it across the input data two samples at a time). This alone however is just a standard convolutional neural network, the power of the Wavenet comes from the dilation (Atrous). The dilation rate is increased by a factor of 2^n for each increasing layer hence between the first and second layer adjacent points are combined, at layer 2 it is every other point, layer 3 is every 4, then 8, 16, 32… As can be seen it rapidly increases whilst keeping the simple size 2 kernel. This therefore means the final predicted data point on the far right can see the very first data point at the bottom left. The rule of thumb for building these layers it that the number of layers N = log2(input_data_window).

Additionally there is concept of causality. In a traditional convolutional layer it doesn’t matter in which order the inputs arrive (aka in a image you care about all surround pixels equally). In song or audio generation however **only** the data points further back in time should be leveraged. This causality is vital to ensure generated songs move forward in time.

These layers exist as part of the Tensorflow Keras pipeline and hence can be incorporated directly to the rest of the Keras modeling components and tools.

#### Sigmoid - Tanh Gated Unit

The above concept of stacking layers is correctly although over simplified. Each layer actually consists of a pair of layers (with the same number of filters) where one has a sigmoid and the other a tanh activation function (as shown in the diagram below from Deepmind’s published paper). 

 - I don't think the above is correct. edit.
 
This acts much like a gate in an LSTM or other Recurrent Network in that the sigmoid can scale up or down (0->1) the importance of the current input values. The tanh then effectively provides the audio signal (-1 to 1) and the multiplication of the two gives the scaled output.

![Wavenet Gated Unit](https://haydensansum.github.io/CS205-Waveforms/imgs/wavenet_gate.png)

_Reference:_ https://arxiv.org/pdf/1609.03499.pdf

## Training a Wavenet

Training a wavenet is the slowest part of the process. To have a functioning music generation model the recommended number of input data points is 1 second, even heavily downsampling normal WAV music files this leads to 8192 input data points (2^13). Hence you might assume there would be 13 layers. Unfortunately continually adding too many dilated layers begins to dilute the sound too much as the data points become unrelated. Hence in practice the approach is to stack groups of layers (referred to through our codebase as stacks) on top of eachother. This additively increases the receptive field. Each stack is 10 layers (1024 field) and hence we require 8 stacks. This a network which is at least 80 layers deeps where each layer is actually a pair of convolutional layers. This starts to uncover the extent of the difficulty in training this sort of model.

To begin with we designed and build a local data pipeline using a custom data generator which yields one input sample at a time to the model fitting. This is optimal as it has reduced memory footprint which was important for local testing. To give an idea of scale, fitting just a single stack for a single epoch took over 2 hours (and a very hot CPU). Achieving parallelization is therefore of paramount importance to develop a working model in any reasonable timeframe.

## Predicting Songs

The final step of the Wavenet model is taking the trained model and producing songs; which it turns out is an artform in itself. The model outputs a softmax for each input data point and generally we’re interested in the latest time step. This output contains a channel of probabilities which represent all the possible values the wave could take on next. The problem here is that if you just take the single highest probability the network may end up getting stuck as samples next to each other will often have similar values causing the prediction to stagnate. To avoid this the softmax output can be used as a weighted distribution from which to sample. Its worth noting that whilst predictions cannot be sped up due to their autoregressive nature, they are very slow. Generating a 10 second clip of audio took around 2-3 hours.






___

- Can we actually treat waves in a discrete fashion and use softmax? That's the big idea. 
- For each wave, we have a continuous variable and that's why people used gaussian mixture models
$$ x = {x_{1}, x_{2}, ...., x_{t}} \rightarrow waveform$$
$$p(x) = \prod_{t=1}^{T} p(x_{t} | x_{1},..., x_{t=1})$$
$$p(x_{t} | x_{1}, ... x_{t-1}) \rightarrow modeled \space by \space a \space stack\space of\space convolutional\space layers$$
$$x_{t} \rightarrow audio \space sample$$
- Our goal is to fit a categorical distribution over the next value $x_{t}$ with a softmax layer
- Our receptive field = (# of layers + filter length - 1)


- In the event we are using compressing & expanding, we are changing our scale and our signal will be:
$$-1 < x_{t} < 1 \space\space and \space \mu = 255$$
- We normalize it and quantize in that space.


##### Process
- Take your input, push it through some causal convolution
- Push the output through some dialated convolution
- Apply tanh and sigmoid functions
- Apply 1x1 convolution
- Keep output
- Rinse and repeat for k layers
- Add them all up 
- Push them through a ReLU
- Push through a 1x1 convolution 
- Push through a ReLU again
- Push through a 1x1 convolution again 
- Push through softmax (because we now can do softmax after applying the law of compounding)
- Then we output 265 numbers which are the probabilities of our next sample and we're done

##### Gated Activation Units:
- This is our tanh times our sigmoid functions as seen in the architecture
- $k \rightarrow layer \space index$
- $f \space and\space g \rightarrow filter \space and \space gate$

##### Residual and Skipped Connections:
- Task here is: given the history, predict the next sample 

##### Conditional WaveNets:
- $h \rightarrow additional \space input$
- multi-speaker setting: speaker identity
- Condition on their identitiy, which is a vector 
- Identity are integers, and we use vector embeddings 
- Text-to-speech: input is text, which we condition on:
	- $p(x) = \prod_{t=1}^{T} p(x_{t} | x_{1},..., x_{t=1}, h)$

##### Global Conditioning 
- $z = tanh(W^{k}_{f}*x + (V^{k}_{f})^{T} h)\space \bigodot \space \sigma(W^{k}_{g} * x + (V^{k}_{f})^{T} h$
- V is a matrix, broadcast over all time dimensions 
##### Local Conditioning
- What is the difference between local and global conditioning?


###### Outstanding Questions
- Where does our filter length come from?
- Why do we need to use dilation to expand the size?
- What's the impact of "skipped" attributes?
- Is dilation = $2^{n}$ up to 512 ? 
	- Answer: It looks like dilation = (n-1) skipped connections
	- Extra: Dilation = $2^{n}$ where n is number of layers
	- Extra: Receptive field size = 1024 when dilation = 512
- How do we convert audio samples, which are continuous, into discrete?
	- Possible Answer: Are 16-bit integer values (i.e., one per timestep) too computationally expensive? For example: $2^{16} = 65,536$ where the right hand side of the equation should be the total number of computed probabilities. How does applying softmax onto this work with tractability? 
	- Law: $$f(x_{t}) = sign(x_{t})\frac{ln(1 + \mu |x_{t}|)}{1 + \mu}$$
		- This is the $\mu$ companding (compressing and expanding) law transformation, we can use this function to quantize it to 256 possible values.
- What is the impact / tradeoffs between using 16-bit integers or quantizing the values?
	- At the end we are running a summation on the $2^{16}$ it's computationally expensive
	- 



_________
- I'm going to speak a little bit about Wavenet version one, what it's composed of, and then some upgrades so there's no confusion.

- First, there was fast wavenet, which is a required optimization, but then there was parallel wavenet, which is a whole new ballgame and is what is displayed on people's Google home pages in America and in Japan

- So wavenet version 1d came from Google Deepmind they came up with this is one kind of concrete product which they came out of it. They made a splash blog post they had they announced the paper and also it has some nice clickable audio examples so this presentation. I've put links up on you know in the Meetup you can click on these get to the web page the key thing he said

- This was the blog post that came out and they described how essentially you know this low-res you know they're really predicting audio samples so that's what they're doing this clever thing and they have tiny diagrams which is very good is that here's the thing and basically let me just play some audio and hopefully this will come out of my speakers Randal Kleiser directed the 1980 American romantic adventure flick can anyone hear that features of the sublime in English poetry and painting 1772 1850 is he coming out at all I hardly have to try again aspects of the sublime in English poetry and art 1772 1850

- Okay, so they have a speech synthesizer which is something where they're moving the parameters around on this very quickly so it's trying to make a synthesizer output speech and so what happens here is it tends to feel a bit singsong II it's a bit weird a bit kind of lumpy in a way that is which is commonly used and say Apple will use is concatenative so what they do for this is they pick that they know what's in just produce the wave signal and then mix them all together, implying that this is derived from a corpus of speech such as the

- So this used to be kind of the winner in the quality war just because you know each individual segment of it is pretty high quality but the problem is if you listen to it carefully now I'll tell you what what's now now you tell me what to listen for you'll hear that it's going from little boost it up and down like the song is all wrong because it's taken from the song from a completely different song

- accurate, but the tones in English poetry at painting 1770 to 80 are a little bit magnificent. good so long comes wavenet characteristics of the sublime in English poetry and painting 1772 1850 can people hear that that's mark be better okay well these aren't mine This is the Google Play so suddenly deepmind comes along and they've done something really very amazing so if we look at Mandarin Chinese which I know nothing about but you might be able to hear this sounds more like a Casio version of someone right was so this is very sort of purposeful wavenet so

- I'm not one to make judgments, but that may be rather nice. I'm not sure what else they can do, but they can play a game where they just let the network loose and try to say stuff without being driven by text. Didn't Atari i'ma tell you to put this in art are they back here with her so this is kind of a model of human speech which is you know that clearly but Victoria taro Seki a district in that self-five it's kind of disturbing so basic basically wavenet has understood both how to form the individual sound

- 